package com.itc.bandit.bandititcdemo;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class SignIn_Activity extends Activity {

	Button Register_New, Login;
	EditText User_Name, Password;
	TextView Forgot;
	String User, passs;
	String first, second, email, password;
	SharedPreferences prefs;
	final Context context = this;

	private ProgressDialog pDialog;

	// URL to get contacts JSON

	// local ip :http://10.6.116.208:8080/HelloWorld/

	// JSON Node names
	private static final String TAG_CONTACTS = "contacts";

	private static final String TAG_ADDRESS = "address";
	private static final String TAG_GENDER = "gender";
	private static final String TAG_PHONE = "phone";
	private static final String TAG_PHONE_MOBILE = "mobile";
	private static final String TAG_PHONE_HOME = "home";
	private static final String TAG_PHONE_OFFICE = "office";

	// contacts JSONArray
	JSONArray contacts = null;

	// Hashmap for ListView
	ArrayList<HashMap<String, String>> contactList;

	// URL to get JSON Array
	private static String url = "http://localhost:8080/HelloWorld/";
	// JSON Node Names
	private static final String TAG_USER = "user";
	private static final String TAG_ID = "id";
	private static final String TAG_NAME = "name";
	private static final String TAG_EMAIL = "email";
	JSONArray user = null;
	
	String json_obj_value;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_signin);

		String login_api = "http://10.6.116.208:8080/HelloWorld/";

		prefs = getSharedPreferences("Login Credentials", MODE_PRIVATE);
		/*
		 * first = prefs.getString("Firstname", ""); second =
		 * prefs.getString("Secondname", "");
		 */

		email = prefs.getString("E_mail", "");
		Log.v("TAG", "email" + email);
		password = prefs.getString("Password_New", "");
		Log.v("TAG", "password" + password);

		Register_New = (Button) findViewById(R.id.registernew);
		Login = (Button) findViewById(R.id.login);
		Forgot = (TextView) findViewById(R.id.forgot);
		User_Name = (EditText) findViewById(R.id.username);
		Password = (EditText) findViewById(R.id.pass);

		Login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				User = User_Name.getText().toString();
				passs = Password.getText().toString();

				if (User.equals("") || passs.equals("")) {

					Toast.makeText(SignIn_Activity.this,
							"Username or Password Cannot be empty", Toast.LENGTH_SHORT).show();

				}

				/*
				 * else if (User.equalsIgnoreCase(email) &&
				 * (passs.equalsIgnoreCase(password))) {
				 */

				else {
					Toast.makeText(SignIn_Activity.this, "Login Valid", Toast.LENGTH_SHORT)
							.show();
				//	new GetContacts().execute();

					//parseValue();
					
					  Intent map_activity = new Intent(SignIn_Activity.this,
					  MapsActivity.class);
                    startActivity(map_activity);
					 }

				// }

			}
		});

		Forgot.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder alert = new AlertDialog.Builder(context);
				alert.setTitle("Forgot Password"); // Set Alert dialog title
													// here
				alert.setMessage("Enter your Mail Id"); // Message here

				// Set an EditText view to get user input
				final EditText input = new EditText(context);
				alert.setView(input);

				alert.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {

								String srt = input.getEditableText().toString();

								Toast.makeText(context, srt, Toast.LENGTH_LONG)
										.show();
							}
						});
				alert.setNegativeButton("CANCEL",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {

								dialog.cancel();
							}
						});
				AlertDialog alertDialog = alert.create();
				alertDialog.show();

			}
		});

		Register_New.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent i = new Intent(getApplicationContext(),
						Registration_Activity.class);
				startActivity(i);

			}

		});
	}


	private class GetContacts extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// Showing progress dialog
			pDialog = new ProgressDialog(SignIn_Activity.this);
			pDialog.setMessage("Please wait...");
			pDialog.setCancelable(false);
			pDialog.show();

		}

		@Override
		protected Void doInBackground(Void... arg0) {
			// Creating service handler class instance

			

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			// Dismiss the progress dialog
			if (pDialog.isShowing())
				pDialog.dismiss();

		}

	}
}