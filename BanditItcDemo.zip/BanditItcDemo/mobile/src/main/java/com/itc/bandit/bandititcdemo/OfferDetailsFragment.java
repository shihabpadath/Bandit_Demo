package com.itc.bandit.bandititcdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;






@SuppressLint("NewApi")
public class OfferDetailsFragment extends Activity {
	
	ListView list;
	String[] string_array;

	// Current Location Details :

	public OfferDetailsFragment() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		

		super.onCreate(savedInstanceState);
		setContentView(R.layout.offer_details);

		String[] web = { "30 Mortensen Avenue Salinas CA 93905","200 Lincoln Ave Salinas CA 93901","65 West Alisal Salinas CA 93901",
				"111 Grand Ave P.O. Box 23660 Oakland CA 94623", "50 Higuera Street San Luis Obispo CA 93401", "30 Mortensen Avenue Salinas CA 93905 ", "200 Lincoln Ave Salinas CA 93901","65 West Alisal Salinas CA 93901",
				"111 Grand Ave P.O. Box 23660 Oakland CA 94623", "50 Higuera Street San Luis Obispo CA 93401","30 Mortensen Avenue Salinas CA 93905 "};

		String[] doctor_address = { "Puma", "Starbucks", "Costa Coffee", "Allen Solly",
				"Reebok", "Samsung", "van Heusen","Cafe Coffee Day", "CODE", "Adidas", "Iphone"};
		
		String[] offer_percent = { "20% OFF on sandals", "40% OFF on Latte", "10 %OFF on Breakfast", "60% OFF on Men Shirts",
				"10% OFF on shoes", "5% OFF Galaxy Note", "10% OFF on women wear","20% OFF on Eskimo Cold Coffee", "50% Flat", "13% OFF on Bags", "10% OFF on Iphone5"};

		Integer[] imageId = { R.drawable.sandals_offer, R.drawable.coffe_maker,
				R.drawable.coffe_maker_offer, R.drawable.cloth_discount,
				R.drawable.sandals_offer, R.drawable.yellow_phone,
				R.drawable.shirt_detailed, R.drawable.coffe_maker,
				R.drawable.cloth_discount, R.drawable.sandals_offer,
				R.drawable.yellow_phone };
		String[] duration = {"0.2","0.3","0.1","1","0.5","2","0.2","0.1","0.2","0.3","0.5"};

		// curent location

		OfferAdapter adapter = new OfferAdapter(this,doctor_address,web,offer_percent,
				imageId,duration);
		list = (ListView) findViewById(R.id.offer_list);
		list.setAdapter(adapter);

		// locationShowAlert();

		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				Intent offer_detailed=new Intent(OfferDetailsFragment.this,OfferDetailedGridHome.class);
				
				offer_detailed.putExtra("key1", list.getAdapter().getItem(position).toString());
				/*offer_detailed.putExtra("",list.get);
				offer_detailed.putExtra("");*/
				startActivity(offer_detailed);

			}
		});

	}
}
