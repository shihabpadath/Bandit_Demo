package com.itc.bandit.bandititcdemo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MapsActivity extends Activity {

    private GoogleMap mMap; // Might be null if Google Play services APK is not
    // available.

    private ProgressDialog pDialog;

    // URL to get contacts JSON
    private static String url = "http://54.191.160.210/dummydata.html";

    // local ip :http://10.6.116.208:8080/HelloWorld/

    // JSON Node names
    private static final String TAG_CONTACTS = "contacts";
    private static final String TAG_ID = "id";
    private static final double TAG_LAT = 14.12;

    private static final String TAG_NAME = "name";
    private static final String TAG_EMAIL = "email";
    private static final String TAG_ADDRESS = "address";
    private static final String TAG_GENDER = "gender";
    private static final String TAG_PHONE = "phone";
    private static final String TAG_PHONE_MOBILE = "mobile";
    private static final String TAG_PHONE_HOME = "home";
    private static final String TAG_PHONE_OFFICE = "office";
    HashMap<String, String> contact;

    // contacts JSONArray
    JSONArray contacts = null;

    // Hashmap for ListView
    ArrayList<HashMap<String, String>> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maphome);
        pDialog = new ProgressDialog(MapsActivity.this);
        contactList = new ArrayList<HashMap<String, String>>();

        new RegisterAsyncTask().execute();

    }

    @Override
    protected void onResume() {
        super.onResume();
        // setUpMapIfNeeded();
    }

    private class RegisterAsyncTask extends AsyncTask<String, Void, String> {
        Boolean result = true;
        String json = null;

        @Override
        protected void onPreExecute() {
            pDialog.setMessage("Please wait...");
            pDialog.show();
        }

        @SuppressWarnings("deprecation")
        @Override
        protected String doInBackground(String... params) {

            JSONParser jParser = new JSONParser();
            // TODO Auto-generated method stub
            try {
                // http://savmysoul.com/
                // getting JSON string from URL
                json = jParser
                        .getJSONFromUrl("http://54.191.160.210/dummydata.html");

            } catch (Exception e) {
                // TODO: handle exception
                result = false;
                e.printStackTrace();
            }
            return json;
        }

        @Override
        protected void onPostExecute(String result) {

            try {
                if (pDialog.isShowing()) {
                    pDialog.dismiss();
                }
                if (this.result) {
                    parseGmailValidateJSON(result);
                } else {
                    showToast(getString(R.string.server_error));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void parseGmailValidateJSON(String result) {

        // TODO Auto-generated method stub

        try {
            JSONObject jsonObj = new JSONObject(result);

            // Getting JSON Array node
            contacts = jsonObj.getJSONArray(TAG_CONTACTS);

            if (result != null) {
                for (int i = 0; i < contacts.length(); i++) {
                    JSONObject c = contacts.getJSONObject(i);

                    String id = c.getString(TAG_ID);

                    double lat_value = Double.parseDouble(id);
                    String name = c.getString(TAG_NAME);
                    String email = c.getString(TAG_EMAIL);
                    String address = c.getString(TAG_ADDRESS);
                    String gender = c.getString(TAG_GENDER);

                    // Phone node is JSON Object
                    JSONObject phone = c.getJSONObject(TAG_PHONE);
                    String mobile = phone.getString(TAG_PHONE_MOBILE);
                    String home = phone.getString(TAG_PHONE_HOME);
                    String office = phone.getString(TAG_PHONE_OFFICE);

                    // tmp hashmap for single contact
                    contact = new HashMap<String, String>();

                    // adding each child node to HashMap key => value
                    contact.put(TAG_ID, String.valueOf(lat_value));

                    contact.put(TAG_NAME, name);
                    contact.put(TAG_EMAIL, email);
                    contact.put(TAG_PHONE_MOBILE, mobile);

                    // adding contact to contact list
                    contactList.add(contact);

                }

                Log.v("contact", "___contact arraylist value" + contactList);
                Log.v("contact", "___contact hash map value" + contact);

                setUpMapIfNeeded();
            }
            // looping through All Contacts

        } catch (JSONException e) {
            e.printStackTrace();
        }
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng arg0) {
                // TODO Auto-generated method stub
                showToast("please select on any deals");
            }
        });
    }

    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the
        // map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((MapFragment) getFragmentManager().findFragmentById(
                    R.id.map)).getMap();

            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    public void showToast(String msg) {
        Toast.makeText(getApplicationContext(), msg,
                Toast.LENGTH_SHORT).show();

    }

    /*
     * marker tutorial
     *
     * https://developers.google.com/maps/documentation/android/marker?hl=FR
     *
     *
     * watch all the map icon related issues...
     */
    private void setUpMap() {

        int[] array_icon = { R.drawable.map_dummy_marker,
                R.drawable.map_dummy_marker, R.drawable.map_dummy_marker,
                R.drawable.map_dummy_marker };
        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(12.45, 75.33))
                .title("Bangalore")
                .icon(BitmapDescriptorFactory
                        .fromResource(R.drawable.current_newicon)));

        CameraUpdate center = CameraUpdateFactory.newLatLng(new LatLng(12.45,
                75.33));
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(8);

        mMap.moveCamera(center);
        mMap.animateCamera(zoom);

        double[] lat_value = { 27.95, 25.95, 26.95, 22.67 };

        double[] long_value = { 55.33, 54.33, 52.33, 55.73 };
        String[] lativalue = { "", "", "", "", "" };

        for (int j = 0; j < contactList.size(); j++) {

            Double.parseDouble(contact.get("id").valueOf(j));

            // Map mTemp=contact.values();

            mMap.addMarker(new MarkerOptions()
                    .position(
                            new LatLng(Double.parseDouble(contactList.get(j)
                                    .get("id")), Double.parseDouble(contactList
                                    .get(j).get("name"))))
                    .snippet("Popu: 4,137,400")
                    .icon(BitmapDescriptorFactory.fromResource(array_icon[j])));



            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {

                @Override
                public boolean onMarkerClick(Marker arg0) {
                    Intent i = new Intent(getApplicationContext(),
                            OfferDetailsFragment.class);
                    startActivity(i);
                    return false;
                }
            });



        }

    }

}
