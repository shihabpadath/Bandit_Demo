package com.itc.bandit.bandititcdemo;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;





public class OfferAdapter extends ArrayAdapter<String> {
	private final Activity context;
	private final String[] web;
	private final Integer[] imageId;
	private final String[] addr;
	private final String[] offer_per;
	private final String[] Duration;

	public OfferAdapter(Activity context, String[] web, String[] addr,String[] offer_per,
			Integer[] imageId,String[] Duration ) {
		super(context, R.layout.list_offer_row, web);
		this.context = context;
		this.web = web;
		this.imageId = imageId;
		this.addr = addr;
		this.offer_per=offer_per;
		this.Duration = Duration;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		LayoutInflater inflater = context.getLayoutInflater();
		View rowView = inflater.inflate(R.layout.list_row, null, true);
		TextView txtTitle = (TextView) rowView.findViewById(R.id.title);
		ImageView imageView = (ImageView) rowView.findViewById(R.id.list_image);
		TextView hospital_addr = (TextView) rowView.findViewById(R.id.artist);
		TextView offer=(TextView) rowView.findViewById(R.id.offername);
		TextView Distance=(TextView) rowView.findViewById(R.id.duration);
		
		
		
		hospital_addr.setText(addr[position]);
		txtTitle.setText(web[position]);
		offer.setText(offer_per[position]);
        imageView.setImageResource(imageId[position]);
        Distance.setText(Duration[position]+ "m");
		
        return rowView;
	}
}
